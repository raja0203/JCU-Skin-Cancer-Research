
<html>
    <head>
        <title>
            Home
        </title>
    </head>
<body>
<?php 
include_once('menu.php');
?>
<div align="center" style="margin:auto" class="content">
	<h1>Help</h1>

	<div style="display:inline-block; text-align: left;">
	<ol>
		<li><a href="files/Blue-card-application-partially-completed.pdf">Blue card application, partially completed</a>
			(Right click and save to save this pdf to your system)
		</li>
	</ol>
	</div>
</div>
<!--This code is used for changing the active item on the menu-->
<script>
$(document).ready(function(){
$('#download').addClass("active");
});
</script>
<!-- The above code is used to change the active item on the menu. To be explicitly pasted on each page that is created-->
</body>
</html>