<?php
header("location:home.php");
?>